-- ZENVORA starter schema for Supabase. Run in Supabase SQL Editor.
-- Keep RLS enabled. Never expose the service_role key in browser code.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 100),
  category text not null check (char_length(category) between 1 and 60),
  description text default '',
  price numeric(10,2) not null check (price > 0 and price <= 1000000),
  image_url text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  customer_name text not null check (char_length(customer_name) between 1 and 80),
  phone text not null check (char_length(phone) between 8 and 18),
  delivery_address text not null check (char_length(delivery_address) between 5 and 500),
  payment_method text not null check (payment_method in ('UPI','COD')),
  payment_status text not null default 'pending' check (payment_status in ('pending','paid','failed')),
  status text not null default 'pending' check (status in ('pending','confirmed','processing','shipped','delivered','cancelled')),
  items jsonb not null,
  total numeric(10,2) not null check (total > 0),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;

create or replace function public.is_admin()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

-- Create a customer profile for each new auth user.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer
set search_path = public
as $$
begin
  insert into public.profiles(id,email,role)
  values(new.id,new.email,'customer')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create policy "Users read own profile" on public.profiles
for select to authenticated using (id = auth.uid() or public.is_admin());
create policy "Admins update profiles" on public.profiles
for update to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "Anyone can read active products" on public.products
for select to anon, authenticated using (active = true or public.is_admin());
create policy "Admins insert products" on public.products
for insert to authenticated with check (public.is_admin());
create policy "Admins update products" on public.products
for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "Admins delete products" on public.products
for delete to authenticated using (public.is_admin());

create policy "Customers read own orders; admins read all" on public.orders
for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "Admins update orders" on public.orders
for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- Orders must be created through this function. Prices are looked up server-side
-- from products; client-supplied totals/prices are not trusted.
create or replace function public.place_order(
  p_customer_name text,
  p_phone text,
  p_delivery_address text,
  p_payment_method text,
  p_items jsonb
) returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_item jsonb;
  v_product public.products%rowtype;
  v_total numeric(10,2) := 0;
  v_items jsonb := '[]'::jsonb;
  v_qty integer;
  v_order_id uuid;
begin
  if v_user is null then raise exception 'Please sign in first'; end if;
  if char_length(trim(p_customer_name)) not between 1 and 80 then raise exception 'Invalid customer name'; end if;
  if char_length(trim(p_phone)) not between 8 and 18 then raise exception 'Invalid phone number'; end if;
  if char_length(trim(p_delivery_address)) not between 5 and 500 then raise exception 'Invalid address'; end if;
  if p_payment_method not in ('UPI','COD') then raise exception 'Invalid payment method'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) < 1 or jsonb_array_length(p_items) > 30 then raise exception 'Invalid cart'; end if;

  for v_item in select value from jsonb_array_elements(p_items)
  loop
    v_qty := (v_item->>'quantity')::integer;
    if v_qty < 1 or v_qty > 20 then raise exception 'Invalid quantity'; end if;
    select * into v_product from public.products
      where id = (v_item->>'product_id')::uuid and active = true;
    if not found then raise exception 'A product is unavailable'; end if;
    v_total := v_total + (v_product.price * v_qty);
    v_items := v_items || jsonb_build_array(jsonb_build_object(
      'product_id',v_product.id,'name',v_product.name,
      'quantity',v_qty,'unit_price',v_product.price
    ));
  end loop;

  if v_total <= 0 or v_total > 1000000 then raise exception 'Order total out of range'; end if;

  insert into public.orders(user_id,customer_name,phone,delivery_address,payment_method,items,total)
  values(v_user,trim(p_customer_name),trim(p_phone),trim(p_delivery_address),p_payment_method,v_items,v_total)
  returning id into v_order_id;
  return v_order_id;
end;
$$;

revoke all on function public.place_order(text,text,text,text,jsonb) from public;
grant execute on function public.place_order(text,text,text,text,jsonb) to authenticated;

-- Seed products (optional demo catalogue).
insert into public.products(name,category,description,price,active) values
('Everyday Classic Sunglasses','Sunglasses','A clean everyday accessory',799,true),
('Essential Cotton T-Shirt','Men''s T-shirt','Comfort-first everyday fit',599,true),
('Relaxed Fit Trousers','Pants','Easy styling, all day',999,true),
('Women''s Everyday Tee',"Women's T-shirt",'A versatile wardrobe staple',649,true),
('Football Fan Jersey','Football Jerseys','Support your team in style',1099,true),
('Sports Training Tee','Sports Collection','Made for active days',699,true)
on conflict do nothing;

-- IMPORTANT: after creating your own account, promote ONLY your intended admin user:
-- update public.profiles set role = 'admin' where email = 'YOUR_ADMIN_EMAIL';
-- Run that statement manually in SQL Editor. Do not add an admin signup form.
