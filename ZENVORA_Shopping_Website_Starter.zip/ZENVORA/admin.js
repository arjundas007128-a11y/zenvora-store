(() => {
 const $=id=>document.getElementById(id),c=window.ZENVORA_CONFIG||{};
 const ready=c.SUPABASE_URL?.startsWith("https://")&&c.SUPABASE_ANON_KEY&&!c.SUPABASE_ANON_KEY.includes("YOUR_");
 const db=ready&&window.supabase?window.supabase.createClient(c.SUPABASE_URL,c.SUPABASE_ANON_KEY):null;
 let admin=false;
 const money=n=>new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:0}).format(n||0);
 const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
 async function check(){
  if(!db){$("adminMessage").textContent="Configure Supabase in config.js first.";return}
  const {data:{user}}=await db.auth.getUser();if(!user)return;
  const {data,error}=await db.from("profiles").select("role").eq("id",user.id).single();
  admin=!error&&data?.role==="admin";
  $("adminMessage").textContent=admin?"Admin access verified.":"This account is not an admin.";
  $("adminArea").classList.toggle("hidden",!admin);if(admin)loadOrders();
 }
 async function loadOrders(){
  const {data,error}=await db.from("orders").select("id,created_at,customer_name,phone,delivery_address,total,status,payment_method,payment_status").order("created_at",{ascending:false});
  if(error){$("adminOrders").textContent=error.message;return}
  $("adminOrders").innerHTML=data.length?data.map(o=>`<article class="order-card"><strong>#${esc(o.id.slice(0,8).toUpperCase())} · ${esc(o.customer_name)}</strong><p>${esc(o.phone)} · ${money(o.total)} · ${esc(o.payment_method)} (${esc(o.payment_status)})</p><p>${esc(o.delivery_address)}</p><label>Status <select data-status="${esc(o.id)}"><option ${o.status==="pending"?"selected":""}>pending</option><option ${o.status==="confirmed"?"selected":""}>confirmed</option><option ${o.status==="processing"?"selected":""}>processing</option><option ${o.status==="shipped"?"selected":""}>shipped</option><option ${o.status==="delivered"?"selected":""}>delivered</option><option ${o.status==="cancelled"?"selected":""}>cancelled</option></select></label><label>Payment <select data-payment="${esc(o.id)}"><option value="pending" ${o.payment_status==="pending"?"selected":""}>pending</option><option value="paid" ${o.payment_status==="paid"?"selected":""}>paid</option><option value="failed" ${o.payment_status==="failed"?"selected":""}>failed</option></select></label></article>`).join(""):"<p>No orders yet.</p>";
  $("adminOrders").querySelectorAll("[data-status]").forEach(s=>s.addEventListener("change",()=>update(s.dataset.status,{status:s.value})));
  $("adminOrders").querySelectorAll("[data-payment]").forEach(s=>s.addEventListener("change",()=>update(s.dataset.payment,{payment_status:s.value})));
 }
 async function update(id,values){const {error}=await db.from("orders").update(values).eq("id",id);$("adminMessage").textContent=error?error.message:"Order updated.";if(!error)loadOrders()}
 $("adminLogin").addEventListener("submit",async e=>{e.preventDefault();if(!db){$("adminMessage").textContent="Configure Supabase first.";return}const {error}=await db.auth.signInWithPassword({email:$("adminEmail").value,password:$("adminPassword").value});$("adminMessage").textContent=error?error.message:"Checking admin role…";if(!error)check()});
 $("reload").addEventListener("click",loadOrders);
 $("productForm").addEventListener("submit",async e=>{e.preventDefault();if(!admin)return;const product={name:$("pName").value.trim(),category:$("pCategory").value.trim(),price:Number($("pPrice").value),image_url:$("pImage").value.trim()||null,description:$("pDescription").value.trim(),active:true};const {error}=await db.from("products").insert(product);$("productMessage").textContent=error?error.message:"Product added.";if(!error)e.target.reset()});
 check();
})();