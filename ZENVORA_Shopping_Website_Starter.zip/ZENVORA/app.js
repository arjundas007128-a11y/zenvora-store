(() => {
  const $ = id => document.getElementById(id);
  const cfg = window.ZENVORA_CONFIG || {};
  const configured = cfg.SUPABASE_URL?.startsWith("https://") && cfg.SUPABASE_ANON_KEY && !cfg.SUPABASE_ANON_KEY.includes("YOUR_");
  const db = configured && window.supabase ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY) : null;
  const money = n => new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:0}).format(Number(n)||0);
  const demoProducts = [
    {id:"demo-1",name:"Everyday Classic Sunglasses",category:"Sunglasses",price:799,image_url:"",description:"A clean everyday accessory"},
    {id:"demo-2",name:"Essential Cotton T-Shirt",category:"Men's T-shirt",price:599,image_url:"",description:"Comfort-first everyday fit"},
    {id:"demo-3",name:"Relaxed Fit Trousers",category:"Pants",price:999,image_url:"",description:"Easy styling, all day"},
    {id:"demo-4",name:"Women's Everyday Tee",category:"Women's T-shirt",price:649,image_url:"",description:"A versatile wardrobe staple"},
    {id:"demo-5",name:"Football Fan Jersey",category:"Football Jerseys",price:1099,image_url:"",description:"Support your team in style"},
    {id:"demo-6",name:"Sports Training Tee",category:"Sports Collection",price:699,image_url:"",description:"Made for active days"}
  ];
  let products = demoProducts, category = "All", cart = JSON.parse(localStorage.getItem("zenvora-cart") || "[]"), user = null;

  function toast(msg){$("toast").textContent=msg;$("toast").style.display="block";setTimeout(()=>$("toast").style.display="none",2600)}
  function saveCart(){localStorage.setItem("zenvora-cart",JSON.stringify(cart));renderCart()}
  function renderCategories(){
    const cats=["All",...new Set(products.map(p=>p.category))];
    $("categories").innerHTML=cats.map(c=>`<button class="category ${category===c?"active":""}" data-category="${escapeHtml(c)}">${escapeHtml(c)}</button>`).join("");
    $("categories").querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>{category=b.dataset.category;renderCategories();renderProducts()}));
  }
  function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
  function renderProducts(){
    const q=$("searchInput").value.trim().toLowerCase();
    const list=products.filter(p=>(category==="All"||p.category===category)&&(`${p.name} ${p.category} ${p.description||""}`).toLowerCase().includes(q));
    $("productGrid").innerHTML=list.length?list.map(p=>`<article class="product-card"><div class="product-image">${p.image_url?`<img src="${escapeHtml(p.image_url)}" alt="${escapeHtml(p.name)}" loading="lazy">`:`<span class="product-placeholder">Z.</span>`}</div><h3>${escapeHtml(p.name)}</h3><div class="product-meta"><span>${escapeHtml(p.category)}</span><strong>${money(p.price)}</strong></div><button data-add="${escapeHtml(p.id)}">Add to cart</button></article>`).join(""):"<p>No products found. Try another search.</p>";
    $("productGrid").querySelectorAll("[data-add]").forEach(b=>b.addEventListener("click",()=>addToCart(b.dataset.add)));
  }
  function addToCart(id){const p=products.find(x=>String(x.id)===String(id));if(!p)return;const row=cart.find(x=>String(x.id)===String(id));if(row)row.qty++;else cart.push({id:p.id,name:p.name,price:Number(p.price),qty:1});saveCart();toast("Added to cart")}
  function renderCart(){
    $("cartCount").textContent=cart.reduce((n,x)=>n+x.qty,0);
    $("cartItems").innerHTML=cart.length?cart.map(x=>`<div class="cart-line"><div><strong>${escapeHtml(x.name)}</strong><br>${money(x.price)} × ${x.qty}</div><div><strong>${money(x.price*x.qty)}</strong><br><button data-remove="${escapeHtml(x.id)}">Remove</button></div></div>`).join(""):'<p class="muted">Your cart is empty.</p>';
    $("cartItems").querySelectorAll("[data-remove]").forEach(b=>b.addEventListener("click",()=>{cart=cart.filter(x=>String(x.id)!==b.dataset.remove);saveCart()}));
    $("cartTotal").textContent=money(cart.reduce((n,x)=>n+x.price*x.qty,0));
  }
  async function loadProducts(){
    if(db){const {data,error}=await db.from("products").select("id,name,category,price,image_url,description").eq("active",true).order("created_at",{ascending:false});if(!error&&data?.length)products=data;else if(error)console.warn("Products:",error.message)}
    renderCategories();renderProducts();
  }
  async function refreshUser(){
    if(!db){$("authMessage").textContent="Demo preview: connect Supabase to enable real accounts and orders.";return}
    const {data}=await db.auth.getSession();user=data.session?.user||null;
    $("authMessage").textContent=user?`Signed in as ${user.email}`:"";
    $("logoutButton").classList.toggle("hidden",!user);
    $("loginButton").textContent="Sign in";
    if(user)loadOrders();
  }
  async function auth(signup){
    if(!db){$("authMessage").textContent="Add Supabase settings in config.js first.";return}
    const email=$("email").value.trim(),password=$("password").value;
    const result=signup?await db.auth.signUp({email,password}):await db.auth.signInWithPassword({email,password});
    $("authMessage").textContent=result.error?result.error.message:(signup?"Check your email to confirm your account.":"Signed in.");
    if(!result.error)await refreshUser();
  }
  async function loadOrders(){
    if(!db||!user){$("ordersList").innerHTML='<p class="muted">Sign in to view your orders.</p>';return}
    const {data,error}=await db.from("orders").select("id,created_at,total,status,payment_method,payment_status").order("created_at",{ascending:false});
    if(error){$("ordersList").textContent=error.message;return}
    $("ordersList").innerHTML=data.length?data.map(o=>`<div class="order-card"><strong>Order #${escapeHtml(o.id.slice(0,8).toUpperCase())}</strong> · ${new Date(o.created_at).toLocaleDateString()}<p>${money(o.total)} · ${escapeHtml(o.payment_method)} · Payment: ${escapeHtml(o.payment_status)}</p><span class="status">${escapeHtml(o.status)}</span></div>`).join(""):"<p class='muted'>No orders yet.</p>";
  }
  async function checkout(e){
    e.preventDefault();
    if(!cart.length){$("checkoutMessage").textContent="Your cart is empty.";return}
    if(!db||!user){$("checkoutMessage").textContent="Please connect Supabase and sign in before placing an order.";return}
    const items=cart.map(x=>({product_id:String(x.id),name:x.name,quantity:x.qty,unit_price:x.price}));
    const total=cart.reduce((n,x)=>n+x.price*x.qty,0);
    const payload={customer_name:$("customerName").value.trim(),phone:$("phone").value.trim(),delivery_address:$("address").value.trim(),payment_method:$("paymentMethod").value,items,total};
    const {data,error}=await db.rpc("place_order",{p_customer_name:payload.customer_name,p_phone:payload.phone,p_delivery_address:payload.delivery_address,p_payment_method:payload.payment_method,p_items:payload.items});
    if(error){$("checkoutMessage").textContent=error.message;return}
    cart=[];saveCart();$("checkoutMessage").textContent=`Order placed! Reference: ${String(data).slice(0,8).toUpperCase()}. Payment is ${payload.payment_method==="UPI"?"pending verification":"cash on delivery"}.`;
    await loadOrders();toast("Order placed successfully");
  }
  $("searchInput").addEventListener("input",renderProducts);
  $("cartButton").addEventListener("click",()=>$("cartDrawer").classList.remove("hidden"));
  $("closeCart").addEventListener("click",()=>$("cartDrawer").classList.add("hidden"));
  $("loginButton").addEventListener("click",e=>{e.preventDefault();auth(false)});
  $("authForm").addEventListener("submit",e=>{e.preventDefault();auth(false)});
  $("signupButton").addEventListener("click",()=>auth(true));
  $("logoutButton").addEventListener("click",async()=>{if(db)await db.auth.signOut();user=null;await refreshUser();$("ordersList").innerHTML='<p class="muted">Sign in to view your orders.</p>'});
  $("refreshOrders").addEventListener("click",loadOrders);
  $("checkoutForm").addEventListener("submit",checkout);
  $("paymentMethod").addEventListener("change",()=> $("upiNote").classList.toggle("hidden",$("paymentMethod").value!=="UPI"));
  $("year").textContent=new Date().getFullYear();
  renderCart();loadProducts();refreshUser();
})();