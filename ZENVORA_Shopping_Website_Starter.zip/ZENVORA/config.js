/*
  Add your Supabase project URL and anon/public key below.
  The anon key is intended for browser use ONLY when Row Level Security is enabled.
  NEVER put a service_role key, database password, or payment secret in this file.
*/
window.ZENVORA_CONFIG = {
  SUPABASE_URL: "YOUR_SUPABASE_PROJECT_URL",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_ANON_KEY",
  STORE_UPI_ID: "YOUR_STORE_UPI_ID", // optional; display only, no payment verification
  CURRENCY: "INR"
};